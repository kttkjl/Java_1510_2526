package ca.bcit.comp2526.a1c;
/**
 * The type of shape.
 * @author Jacky
 * @version 1.0
 */
public enum ShapeType {
    /**
     * The shapes allowed.
     */
    RECTANGLE, TRIANGLE, DIAMOND;
}
